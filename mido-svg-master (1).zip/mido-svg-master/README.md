#*** MIDO SVG Project ***
***********************

Subject: https://github.com/oliviercailloux/projets/blob/master/mido_svg.adoc  

## **SEANCE 1:**  
Team 1: Focus on the data we need     
Team 2: Focus on the svg generator  